# Import block
import os
import time
import os.path as osp

import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader

from torchvision import datasets
from torchvision import transforms
import torchvision

import matplotlib.pyplot as plt
from PIL import Image

import random
class ConvNet(nn.Module):
    def __init__(self):
        super(ConvNet, self).__init__()

        # 第一层卷积层: 输入通道数=3，输出通道数=4，卷积核大小=3x3
        self.conv1 = nn.Conv2d(3, 4, 3)

        # 最大池化层: 2x2 大小的池化窗口，步幅=2
        self.pool = nn.MaxPool2d(2, 2)

        # 第二层卷积层: 输入通道数=4，输出通道数=8，卷积核大小=3x3
        self.conv2 = nn.Conv2d(4, 8, 3)

        # 第一个全连接层: 输入维度=8x6x6，输出维度=32
        self.fc1 = nn.Linear(8 * 6 * 6, 32)

        # 第二个全连接层: 输入维度=32，输出维度=10（用于 10 分类问题）
        self.fc2 = nn.Linear(32, 10)

    def forward(self, x):
        # 第一层卷积层 + ReLU激活函数 + 最大池化层
        x = self.pool(torch.relu(self.conv1(x)))

        # 第二层卷积层 + ReLU激活函数 + 最大池化层
        x = self.pool(torch.relu(self.conv2(x)))

        # 将特征张量展平，以便进行全连接层的处理
        x = x.view(-1, 8 * 6 * 6)

        # 第一个全连接层 + ReLU激活函数
        x = torch.relu(self.fc1(x))

        # 第二个全连接层，用于输出分类结果
        x = self.fc2(x)

        return x

def train_batch(model, image, target):
    """
    Perform one training batch iteration.

    Args:
        model (torch.nn.Module): The machine learning model to train.
        image (torch.Tensor): Batch of input data (images).
        target (torch.Tensor): Batch of target labels.

    Returns:
        torch.Tensor: Model output (predictions) for the batch.
        torch.Tensor: Loss value calculated by the defined loss function loss_fn().
    """

    ##################### Write your answer here ##################
    output = model(image)
    loss_fn =nn.CrossEntropyLoss()
    loss = loss_fn(output , target)
    ###############################################################

    return output, loss

def test_batch(model, image, target):
    """
    Perform one testing batch iteration.

    Args:
        model (torch.nn.Module): The machine learning model to evaluate.
        image (torch.Tensor): Batch of input data (images).
        target (torch.Tensor): Batch of target labels.

    Returns:
        torch.Tensor: Model output (predictions) for the batch.
        torch.Tensor: Loss value calculated for the batch.
    """

    ##################### Write your answer here ##################
    output = model(image)
    loss_fn = nn.CrossEntropyLoss()
    loss = loss_fn(output, target)
    ###############################################################

    return output, loss

#主函数，定义了主要过程
def main():
    # hyperparameters
    # random seed
    SEED = 1  # 随机数种子，用于复现随机性操作的结果
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed(SEED)

    NUM_CLASS = 10  # 分类问题的类别数量

    # Training
    BATCH_SIZE = 128  # 每个训练批次中包含的样本数量
    NUM_EPOCHS = 2  # 训练迭代的总轮数
    EVAL_INTERVAL = 1  # 用于设定多少个 epoch 后进行模型性能评估
    SAVE_DIR = './log'  # 保存训练日志和模型检查点的目录

    # Optimizer
    LEARNING_RATE = 1e-1  # 学习率，用于控制权重更新的步长
    MOMENTUM = 0.9  # 动量参数，用于加速权重更新
    STEP = 5  # 学习率调度的步数
    GAMMA = 0.5  # 学习率调度的衰减率


    #device
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")  # 如果cuda可用就使用GPU，否则使用CPU

    # cifar10 transform

    # 定义训练数据的图像预处理操作：
    # 1. 随机裁剪图像为 32x32 大小，同时进行 4 像素的填充。
    # 2. 随机水平翻转图像。
    # 3. 将图像转换为 PyTorch Tensor 类型。
    # 4. 标准化图像像素值，使用指定的均值和标准差。
    transform_cifar10_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    # 定义测试数据的图像预处理操作：
    # 1. 将图像转换为 PyTorch Tensor 类型。
    # 2. 标准化图像像素值，使用指定的均值和标准差。
    transform_cifar10_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    # 创建训练数据集对象，指定数据存储路径、是否是训练数据、是否需要下载数据、以及预处理操作。
    train_set = torchvision.datasets.CIFAR10(root='../data', train=True,
                                            download=True, transform=transform_cifar10_train)

    # 创建训练数据的数据加载器，指定每个批次的大小、是否随机打乱数据、以及用于加载数据的工作线程数。
    train_dataloader = torch.utils.data.DataLoader(train_set, batch_size=BATCH_SIZE,
                                              shuffle=True, num_workers=2)

    # 创建测试数据集对象，指定数据存储路径、是否是训练数据、是否需要下载数据、以及预处理操作。
    test_set = torchvision.datasets.CIFAR10(root='../data', train=False,
                                           download=True, transform=transform_cifar10_test)

    # 创建测试数据的数据加载器，指定每个批次的大小、不打乱数据顺序、以及用于加载数据的工作线程数。
    test_dataloader = torch.utils.data.DataLoader(test_set, batch_size=BATCH_SIZE,
                                             shuffle=False, num_workers=2)

    # 定义类别标签的名称列表，对应 CIFAR-10 数据集中的 10 个类别。
    class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']
    torch.backends.cudnn.deterministic = True
    model = ConvNet()
    model.to(device)

    # 定义优化器：随机梯度下降 (SGD)
    # - model.parameters()：将模型的参数传递给优化器，以便优化这些参数
    # - lr=LEARNING_RATE：学习率，控制每次参数更新的步长
    # - momentum=MOMENTUM：动量，一种加速收敛的技巧，用于处理参数更新时的惯性
    optimizer = optim.SGD(model.parameters(), lr=LEARNING_RATE, momentum=MOMENTUM)

    # 学习率调度器（Scheduler）：调整学习率的策略
    # - torch.optim.lr_scheduler.StepLR(optimizer, step_size=STEP, gamma=GAMMA)：
    #   - optimizer：要调整学习率的优化器（这里是之前定义的SGD优化器）
    #   - step_size=STEP：学习率调整的步数，即经过多少个epoch后调整学习率
    #   - gamma=GAMMA：学习率缩放因子，用于降低学习率
    # 该调度器会在每经过 `step_size` 个epoch 后，将学习率乘以 `gamma`。
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=STEP, gamma=GAMMA)

    # criterion = loss_fn



    # 遍历每个epoch进行训练
    for epoch in range(NUM_EPOCHS):
        model.train()  # 设置模型为训练模式
        torch.cuda.empty_cache()  # 清空GPU缓存

        # 训练阶段
        running_cls_loss = 0.0  # 用于存储每个batch的训练损失
        running_cls_corrects = 0  # 用于存储每个batch的训练正确预测的样本数

        # 遍历训练数据集的每个batch
        for batch_idx, (image, target) in enumerate(train_dataloader):

            image = image.to(device)  # 将图像数据移动到GPU（如果可用）
            target = target.to(device)  # 将标签数据移动到GPU（如果可用）

            # 训练模型并获取输出和损失
            outputs, loss = train_batch(model, image, target)
            _, preds = torch.max(outputs, 1)  # 获取预测的类别

            loss_data = loss.data.item()
            if np.isnan(loss_data):
                raise ValueError('loss is nan while training')  # 检查损失是否为NaN
            running_cls_loss += loss.item()
            running_cls_corrects += torch.sum(preds == target.data)  # 统计正确预测的样本数

            loss.backward()  # 反向传播计算梯度
            optimizer.step()  # 使用优化器更新模型参数
            optimizer.zero_grad()  # 清空梯度

        # 计算当前epoch的平均损失和准确度
        epoch_loss = running_cls_loss / len(train_set)
        epoch_acc = running_cls_corrects.double() / len(train_set)

        print(f'Epoch: {epoch + 1}/{NUM_EPOCHS} Train Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')


        # 调整学习率
        scheduler.step()  # 调整学习率策略

        # 测试阶段
        if (epoch + 1) % EVAL_INTERVAL == 0 or (epoch + 1) == NUM_EPOCHS:
            print('Begin test......')
            model.eval()  # 设置模型为评估模式

            val_loss = 0.0  # 用于存储测试损失
            val_corrects = 0  # 用于存储测试正确预测的样本数

            # 遍历测试数据集的每个batch
            for batch_idx, (image, target) in enumerate(test_dataloader):
                image = image.to(device)  # 将图像数据移动到GPU（如果可用）
                target = target.to(device)  # 将标签数据移动到GPU（如果可用）

                # 测试模型并获取输出和损失
                outputs, loss = test_batch(model, image, target)
                _, preds = torch.max(outputs, 1)  # 获取预测的类别

                val_loss += loss.item()
                val_corrects += torch.sum(preds == target.data)  # 统计正确预测的样本数

            val_loss = val_loss / len(test_set)  # 计算平均测试损失
            val_acc = val_corrects.double() / len(test_set)  # 计算测试准确度
            print(f'Test Loss: {val_loss:.4f} Acc: {val_acc:.4f}')

            # 在最后一个epoch保存模型
            if (epoch + 1) == NUM_EPOCHS:

                state = {
                    'state_dict': model.state_dict(),
                    'acc': epoch_acc,
                    'epoch': (epoch + 1),
                }

                # 检查目录是否存在，如果不存在则创建
                if not os.path.exists(SAVE_DIR):
                    os.makedirs(SAVE_DIR)

                # 保存模型状态
                torch.save(state, osp.join(SAVE_DIR, 'checkpoint_%s.pth' % (str(epoch + 1))))

    inputs, classes = next(iter(test_dataloader))
    input = inputs[0].to(device)
    probabilities =torch.softmax(model(input), dim =1)
    predict_label =torch.argmax(probabilities, dim=1).item()
    predicted_class = class_names[predict_label]
    predicted_probability = probabilities[0][predict_label].item()
    image = input.cpu().numpy().transpose((1, 2, 0))
    plt.imshow(image)
    plt.text(17, 30, f'Predicted Class: {predicted_class}\nProbability: {predicted_probability:.2f}',
             color='white', backgroundcolor='black', fontsize=8)
    plt.show()

    # Print probabilities for each class
    print('Print probabilities for each class:')
    for i in range(len(class_names)):
        print(f'{class_names[i]}: {probabilities[i].item():.4f}')


if __name__ == '__main__':
    main()
