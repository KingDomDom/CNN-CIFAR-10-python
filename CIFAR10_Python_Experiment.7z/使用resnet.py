import os
import time
import os.path as osp
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms, models
import torchvision
import matplotlib.pyplot as plt
import random
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

def train_batch(model, image, target):
    # Perform one training batch iteration.
    output = model(image)
    loss_fn = nn.CrossEntropyLoss()
    loss = loss_fn(output, target)
    return output, loss


def test_batch(model, image, target):
    # Perform one testing batch iteration.
    output = model(image)
    loss_fn = nn.CrossEntropyLoss()
    loss = loss_fn(output, target)
    return output, loss


def train_and_evaluate(learning_rate, momentum, gamma, step, EVAL_INTERVAL):
    # Define your model, optimizer, and other necessary components
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    NUM_CLASS = 10
    BATCH_SIZE = 64
    NUM_EPOCHS = 1
    SAVE_DIR = './log'
    transform_cifar10_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    transform_cifar10_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    train_set = torchvision.datasets.CIFAR10(root='../data', train=True,
                                             download=True, transform=transform_cifar10_train)

    train_dataloader = torch.utils.data.DataLoader(train_set, batch_size=BATCH_SIZE,
                                                   shuffle=True, num_workers=2)

    test_set = torchvision.datasets.CIFAR10(root='../data', train=False,
                                            download=True, transform=transform_cifar10_test)

    test_dataloader = torch.utils.data.DataLoader(test_set, batch_size=BATCH_SIZE,
                                                  shuffle=False, num_workers=2)


    model = models.resnet18(weights=None)
    num_features = model.fc.in_features
    model.fc = nn.Linear(num_features, NUM_CLASS)
    model.to(device)

    optimizer = optim.SGD(model.parameters(), lr=learning_rate, momentum=momentum)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=step, gamma=gamma)
    training_loss = []
    training_acc = []
    testing_loss = []
    testing_acc = []

    for epoch in range(NUM_EPOCHS):
        model.train()
        torch.cuda.empty_cache()
        running_cls_loss = 0.0
        running_cls_corrects = 0

        for batch_idx, (image, target) in enumerate(train_dataloader):
            image = image.to(device)
            target = target.to(device)

            outputs, loss = train_batch(model, image, target)
            _, preds = torch.max(outputs, 1)

            loss_data = loss.data.item()
            if np.isnan(loss_data):
                raise ValueError('loss is nan while training')
            running_cls_loss += loss.item()
            running_cls_corrects += torch.sum(preds == target.data)

            loss.backward()
            optimizer.step()
            optimizer.zero_grad()

        epoch_loss = running_cls_loss / len(train_set)
        epoch_acc = running_cls_corrects.double() / len(train_set)
        print(f'Epoch: {epoch + 1}/{NUM_EPOCHS} Train Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}')
        training_loss.append(epoch_loss)
        training_acc.append(epoch_acc.cpu().detach().numpy())

        scheduler.step()

        if (epoch + 1) % EVAL_INTERVAL == 0 or (epoch + 1) == NUM_EPOCHS:
            print('Begin test...')
            model.eval()
            val_loss = 0.0
            val_corrects = 0

            for batch_idx, (image, target) in enumerate(test_dataloader):
                image = image.to(device)
                target = target.to(device)

                outputs, loss = test_batch(model, image, target)
                _, preds = torch.max(outputs, 1)

                val_loss += loss.item()
                val_corrects += torch.sum(preds == target.data)

            val_loss = val_loss / len(test_set)
            val_acc = val_corrects.double() / len(test_set)
            print(f'Test Loss: {val_loss:.4f} Acc: {val_acc:.4f}')
            testing_loss.append(val_loss)
            testing_acc.append(val_acc.cpu().detach().numpy())

            if (epoch + 1) == NUM_EPOCHS:

                state = {
                    'state_dict': model.state_dict(),
                    'acc': epoch_acc,
                    'epoch': (epoch + 1),
                }

                if not os.path.exists(SAVE_DIR):
                    os.makedirs(SAVE_DIR)

                torch.save(state, osp.join(SAVE_DIR, 'checkpoint_%s.pth' % (str(epoch + 1))))
    class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

    # 获取第一张测试集图像
    test_iterator = iter(test_dataloader)
    first_test_image, _ = next(test_iterator)
    first_test_image = first_test_image[0].cpu().numpy().transpose((1, 2, 0))
    first_test_image = (first_test_image * np.array([0.2023, 0.1994, 0.2010])) + np.array([0.4914, 0.4822, 0.4465])
    first_test_image = np.clip(first_test_image, 0, 1)

    # 将Numpy数组转换为PIL图像
    first_test_image = Image.fromarray((first_test_image * 255).astype(np.uint8))
    first_test_image.show()
    # 转移到模型所使用的设备
    first_test_image = first_test_image.to(device)

    # 运行模型进行预测
    with torch.no_grad():
        probabilities = torch.softmax(model(first_test_image), dim=1)
        predict_label = torch.argmax(probabilities, dim=1).item()
        predicted_class = class_names[predict_label]
        predicted_probability = probabilities[0][predict_label].item()

    # # 将第一张测试图像从Tensor转换为Numpy数组
    # first_test_image = first_test_image[0].cpu().numpy().transpose((1, 2, 0))
    # first_test_image = (first_test_image * np.array([0.2023, 0.1994, 0.2010])) + np.array([0.4914, 0.4822, 0.4465])
    # first_test_image = np.clip(first_test_image, 0, 1)
    #
    # # 将Numpy数组转换为PIL图像
    # first_test_image = Image.fromarray((first_test_image * 255).astype(np.uint8))
    # first_test_image.show()
    # 在图像上绘制分类标签和最大预测概率
    draw = ImageDraw.Draw(first_test_image)
    font = ImageFont.load_default()  # 使用默认字体

    # 构建要绘制的文本
    text = f"Predicted Class: {predicted_class}\nMax Probability: {predicted_probability:.4f}"

    # 计算文本尺寸以进行定位
    text_size = draw.textsize(text, font)
    text_x = (first_test_image.width - text_size[0]) / 2
    text_y = first_test_image.height - text_size[1]

    # 绘制文本
    draw.text((text_x, text_y), text, (255, 255, 255), font=font)

    # 显示图像
    first_test_image.show()

    # 保存带有文本的图像
    first_test_image.save("predicted_image.png")

    return model
if __name__ == '__main__':

    learning_rate = 0.1
    momentum = 0.5
    step = 5
    gamma = 0.9
    EVAL_INTERVAL = 1
    results = []

    SEED = 1
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed(SEED)

    result = train_and_evaluate(learning_rate, momentum, gamma, step, EVAL_INTERVAL)




